<?php
// FROM HASH: 728b83c847a85ac771bde598cc0d8653
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= $__templater->includeTemplate('base_prefix_group_delete', $__vars);
	return $__finalCompiled;
});