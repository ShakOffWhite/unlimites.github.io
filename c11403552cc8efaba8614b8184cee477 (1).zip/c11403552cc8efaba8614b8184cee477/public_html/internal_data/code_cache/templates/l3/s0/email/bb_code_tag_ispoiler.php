<?php
// FROM HASH: 19805883282c390037af68305b6b2cbd
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= '<span class="inlineSpoilerPlaceholder">' . 'Содержимое спойлера скрыто.' . '</span>';
	return $__finalCompiled;
});