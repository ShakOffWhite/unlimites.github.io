<?php
// FROM HASH: 6e6b2be0c1cdbc084725cad0c0976b4d
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= $__templater->includeTemplate('base_prompt_group_delete', $__vars);
	return $__finalCompiled;
});