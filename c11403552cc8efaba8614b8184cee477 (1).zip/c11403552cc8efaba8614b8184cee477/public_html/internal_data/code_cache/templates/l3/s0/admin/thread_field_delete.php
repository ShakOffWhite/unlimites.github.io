<?php
// FROM HASH: 141cf1104ee10d4d7542844fd6049125
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= $__templater->includeTemplate('base_custom_field_delete', $__vars);
	return $__finalCompiled;
});