<?php
// FROM HASH: 09af5c3d5de6b8671b80f862c0436394
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= '.block--phrase--custom
{
	.block-container
	{
		border-color: red;
		border-top-width: @xf-borderSizeFeature;
	}
}

.block--phrase--parentCustom
{
	.block-container
	{
		border-color: orange;
		border-top-width: @xf-borderSizeFeature;
	}
}';
	return $__finalCompiled;
});