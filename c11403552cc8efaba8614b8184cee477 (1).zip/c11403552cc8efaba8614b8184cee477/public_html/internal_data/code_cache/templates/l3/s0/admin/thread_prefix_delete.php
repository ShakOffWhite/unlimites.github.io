<?php
// FROM HASH: a0d768a09b4c42c8d1286ba1e49a66cf
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= $__templater->includeTemplate('base_prefix_delete', $__vars);
	return $__finalCompiled;
});