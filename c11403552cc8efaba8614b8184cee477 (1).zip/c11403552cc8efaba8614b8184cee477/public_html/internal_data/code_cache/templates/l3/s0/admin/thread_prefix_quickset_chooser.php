<?php
// FROM HASH: f546c8cd56a82b1f10fd001332bb924d
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__compilerTemp1 = $__vars;
	$__compilerTemp1['prefixType'] = 'thread';
	$__finalCompiled .= $__templater->includeTemplate('base_prefix_quickset_chooser', $__compilerTemp1);
	return $__finalCompiled;
});