<?php
// FROM HASH: 2de34331f6a8f8172ac3b76f2eeb9cfc
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= $__templater->includeTemplate('base_prompt_group_edit', $__vars);
	return $__finalCompiled;
});