<?php
// FROM HASH: 26ef0fe0b386d7db377e4b60438b4279
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= $__templater->includeTemplate('base_prompt_delete', $__vars);
	return $__finalCompiled;
});