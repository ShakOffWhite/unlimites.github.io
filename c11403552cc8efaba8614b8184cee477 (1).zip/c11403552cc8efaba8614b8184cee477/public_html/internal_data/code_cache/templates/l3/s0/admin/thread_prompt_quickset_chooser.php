<?php
// FROM HASH: 7435355029c4e394ae1c701666262ce3
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__compilerTemp1 = $__vars;
	$__compilerTemp1['prefixType'] = 'thread';
	$__finalCompiled .= $__templater->includeTemplate('base_prompt_quickset_chooser', $__compilerTemp1);
	return $__finalCompiled;
});