<?php
// FROM HASH: 306dc99428f4a8accfdfe17e351b8a66
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= $__templater->includeTemplate('base_prefix_group_edit', $__vars);
	return $__finalCompiled;
});