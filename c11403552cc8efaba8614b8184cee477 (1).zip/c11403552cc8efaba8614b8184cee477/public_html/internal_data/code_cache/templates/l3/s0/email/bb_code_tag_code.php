<?php
// FROM HASH: 8d8fcdbc8bdaccf3c8e7a47b4cc75ad2
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= '<pre class="code" dir="ltr">' . $__templater->escape($__vars['content']) . '</pre>';
	return $__finalCompiled;
});