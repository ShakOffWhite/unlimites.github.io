<?php
// FROM HASH: 4f823865bfd3054023900c7e3c87152b
return array('macros' => array(), 'code' => function($__templater, array $__vars)
{
	$__finalCompiled = '';
	$__finalCompiled .= '<div class="mediaPlaceholder">' . 'Вставленные медиа' . '</div>';
	return $__finalCompiled;
});